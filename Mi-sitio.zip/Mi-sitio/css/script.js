let boton = document.createElement('button');

boton.textContent = 'Cambiar color 🎨';

document.body.appendChild(boton);

let colores = ['pink', 'purple', 'black', 'darkred'];
let indice = 0;

boton.addEventListener('click', function() {
    document.body.style.backgroundColor = colores[indice];
    indice++;

    if (indice >= colores.length) {
        indice = 0;
    }
});